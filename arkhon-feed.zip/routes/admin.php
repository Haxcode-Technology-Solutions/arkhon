<?php
// Admin routes placeholder
